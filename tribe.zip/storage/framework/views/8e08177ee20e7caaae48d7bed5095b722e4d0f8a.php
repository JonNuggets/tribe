<!doctype html>
<html>
    <?php echo $__env->make('includes.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <body class="nav-md">
        <div class="container body">
          <div class="main_container">
              <?php echo $__env->make('includes.navigation.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo $__env->make('includes.admin.topnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>
        <?php echo $__env->make('includes.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>