{!! HTML::script('gentelella/vendors/jquery/dist/jquery.min.js') !!}
{!! HTML::script('gentelella/vendors/bootstrap/dist/js/bootstrap.min.js') !!}
{!! HTML::script('gentelella/vendors/fastclick/lib/fastclick.js') !!}
{!! HTML::script('gentelella/vendors/nprogress/nprogress.js') !!}
{!! HTML::script('gentelella/vendors/Chart.js/dist/Chart.min.js') !!}
{!! HTML::script('gentelella/vendors/gauge.js/dist/gauge.min.js') !!}
{!! HTML::script('gentelella/bootstrap-progressbar/bootstrap-progressbar.min.js') !!}
{!! HTML::script('gentelella/vendors/iCheck/icheck.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net/js/jquery.dataTables.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-buttons/js/dataTables.buttons.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-buttons/js/buttons.flash.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-buttons/js/buttons.html5.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-buttons/js/buttons.print.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-responsive/js/dataTables.responsive.min.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js') !!}
{!! HTML::script('gentelella/vendors/datatables.net-scroller/js/dataTables.scroller.min.js') !!}
{!! HTML::script('gentelella/vendors/jszip/dist/jszip.min.js') !!}
{!! HTML::script('gentelella/vendors/pdfmake/build/pdfmake.min.js') !!}
{!! HTML::script('gentelella/vendors/pdfmake/build/vfs_fonts.js') !!}

<!-- Custom Theme Scripts -->
{!! HTML::script('gentelella/build/js/custom.min.js') !!}